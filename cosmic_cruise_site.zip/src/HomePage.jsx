
import React from "react";
import { useState } from "react";

export default function HomePage() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <main className="min-h-screen bg-gradient-to-br from-black via-blue-900 to-black text-white p-4 font-sans">
      <header className="text-center py-6">
        <img src="/logo.png" alt="Cosmic Cruise Logo" className="mx-auto w-24 h-24 mb-4" />
        <h1 className="text-4xl font-bold">Cosmic Cruise</h1>
        <p className="text-lg text-blue-300 mt-2">Exploring Science, Politics, Geopolitics & Technology</p>
      </header>

      <section className="max-w-3xl mx-auto my-8 text-center">
        <h2 className="text-2xl font-semibold mb-4">Who Are We?</h2>
        <p className="text-gray-300 leading-relaxed">
          Cosmic Cruise is your launchpad into the realms of knowledge. Whether you're a deep diver or a casual
          scroller, we break down the complexities of science, politics, geopolitics, and cutting-edge tech to deliver
          insight that sticks. Join us as we navigate through the noise and focus on truth.
        </p>
      </section>

      <section className="max-w-xl mx-auto my-12 bg-white text-black p-6 rounded-2xl shadow-xl">
        <h2 className="text-xl font-bold mb-4">Ask Us Anything</h2>
        {submitted ? (
          <p className="text-green-600 font-semibold">Thank you! Your question has been submitted.</p>
        ) : (
          <form action="https://formspree.io/f/mqkrlndp" method="POST" className="space-y-4" onSubmit={() => setSubmitted(true)}>
            <input type="text" name="name" placeholder="Your Name (optional)" className="w-full p-2 border rounded" />
            <input type="email" name="email" placeholder="Your Email (optional)" className="w-full p-2 border rounded" />
            <textarea name="question" placeholder="Your Question..." className="w-full p-2 border rounded" required></textarea>
            <textarea name="suggestion" placeholder="Any Suggestions? (optional)" className="w-full p-2 border rounded"></textarea>
            <select name="rating" className="w-full p-2 border rounded">
              <option value="">Rate Our Content (1-5)</option>
              <option value="1">1 - Poor</option>
              <option value="2">2 - Fair</option>
              <option value="3">3 - Good</option>
              <option value="4">4 - Very Good</option>
              <option value="5">5 - Excellent</option>
            </select>
            <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
              Submit
            </button>
          </form>
        )}
      </section>

      <footer className="text-center text-gray-400 mt-12 py-6 border-t border-gray-700">
        &copy; 2025 Cosmic Cruise. All rights reserved.
      </footer>
    </main>
  );
}
