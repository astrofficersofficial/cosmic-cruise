
# Cosmic Cruise

A professional React + Tailwind site for a knowledge-driven channel covering Science, Politics, Geopolitics, and Tech.

## How to Run

1. Install Node.js
2. Run `npm install`
3. Run `npm run dev`

## Deploy to Vercel

- Go to https://vercel.com
- Connect your GitHub repo or upload this folder
- Done!

Form submissions will go to: astrofficersofficial@gmail.com (via Formspree)
